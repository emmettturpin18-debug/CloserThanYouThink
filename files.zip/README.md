# Closer Than You Think (first build)
One static file: `index.html`. No install needed; works offline.

## Run on your MacBook (M4)
Double-click `index.html` (opens in Chrome), or in Terminal: `cd` into this folder, then `python3 -m http.server 8000` and open http://localhost:8000.

## Publish free (you do this; I created no accounts)
1. Make a free GitHub account, create a public repo, upload `index.html` and `README.md`.
2. Repo Settings > Pages > deploy from the main branch, root folder. Your URL appears there.
3. To update: edit/upload the file again; Pages republishes.
Free plans have limits and can change; check GitHub Pages' current terms.

## Data
Questions are in the `RAW` list at the top of the script (title|clue|year|month|day|Wikipedia page|kid-friendly 1/0|topic|region). Add lines to extend. Source links are Wikipedia pages written from memory; I had no internet, so link targets and dates are NOT verified. Check them before relying on them.

## Local vs online
Everything is local (rankings in this browser's localStorage). No global leaderboard exists yet.

## Update 2: characters, coins, abilities, levels
Keep the `assets/` folder next to `index.html` (upload it too when publishing). Characters are `assets/chars/c1-c6.png`, cropped from your kitchen sheet (no ZIP/manifest was received). Progress saves in this browser's localStorage; older saves load fine.
